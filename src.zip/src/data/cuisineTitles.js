const cuisineTitles = [
    "Djaj mhamer bdeghmira",
    "Couscous",
    "Tangia",
    "Rfissa",
    "Pastilla",
    "Harira",
    "Baghrir",
    "Msemmen",
    "Chebakia",
    "Seffa",
    
  ];
  
  export default cuisineTitles;
  